#!/bin/bash 
expressvpn connect

