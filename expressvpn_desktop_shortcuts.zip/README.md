# by Jonesy167
# Expressvpn-Desktop-Shortcuts
Adds desktop shortcuts to connect, disconnect and check status of Expressvpn on Ubuntu - no need to run expressvpn from terminal, simply double click on appropriate icon to excecute (like Windows)


#the actual commands it runs are:
expressvpn connect smart # uses expressvpn's smart conenct so should connect to server with lowest latency
expressvpn disconnect # does what it says
expressvpn status # produces a popup showing expressvpn status, closes automatically after 3 seconds


#tested on Ubuntu 16.10 and 17.10

*****N.B this is not tested, supported or associated to Expressvpn in any way, Expressvpn do however have my full consent to use any of this code for free for an unlimed period - providing they reference Jonesy167 in any documentation and readme files. 
