#!/bin/bash 
expressvpn status
sleep 3
exit

