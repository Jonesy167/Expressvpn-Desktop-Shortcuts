#!/bin/bash 
expressvpn disconnect
